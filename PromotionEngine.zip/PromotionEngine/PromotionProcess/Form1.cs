﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Resources;
using System.Reflection;
using System.Collections;

namespace PromotionProcess
{
    public partial class Form1 : Form
    {
        ResourceManager rm = new ResourceManager("PromotionProcess.Properties.Resources", Assembly.GetExecutingAssembly());
        List<cartDetails> details = new List<cartDetails>();
        public Form1()
        {
            InitializeComponent();
            
            ResourceSet resourceSet = rm.GetResourceSet(CultureInfo.CurrentUICulture, true, true);
            foreach (DictionaryEntry entry in resourceSet)
            {
                comboBox1.Items.Add(entry.Key.ToString());
            }

            comboBox1.SelectedItem = "A";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label1.Text = rm.GetString(comboBox1.SelectedItem.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            details.Add(new cartDetails() { ItemName = comboBox1.SelectedItem.ToString(),ItemCost = Convert.ToInt32(label1.Text), ItemQty = Convert.ToInt32(textBox1.Text) });
            label1.Text = "";
            textBox1.Text = "";
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            IactivePromotionsCalculations promotion = new activePromotionsCalculations();
            promotion.totalCost(details);
        }

        
    }
}
