﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionProcess
{
    public class activePromotionsCalculations : IactivePromotionsCalculations
    {
        public activePromotionsCalculations()
        {

        }

        public int totalCost(List<cartDetails> cardDetails)
        {
           int Acost = calculateSIDA(cardDetails.Where(t => t.ItemName == "A").ToList());
           int Bcost = calculateSIDB(cardDetails.Where(t => t.ItemName == "B").ToList());
           int CandDCost = calculateCandD(cardDetails.Where(t=> t.ItemName == "C" || t.ItemName == "D").ToList());
           return Acost + Bcost + CandDCost;
        }

        private int calculateSIDA(List<cartDetails> sidA)
        {
            int totalQty = sidA.Sum(t => t.ItemQty);
            int Acost = sidA.Select(t=>t.ItemCost).FirstOrDefault();
            int totalcost = 0;
            if (totalQty >= 3)
            {
                if (totalQty % 3 == 0)
                {
                    totalcost = (totalQty / 3) * 130;
                }
                else
                {
                    totalcost = (totalQty / 3) * 130 + ((totalQty % 3) * Acost);
                }
            }

            else
            {
                totalcost = totalQty * Acost;
            }
            return totalcost;
        }

        private int calculateSIDB(List<cartDetails> sidB)
        {
            int totalcost = 0;
            int totalQty = sidB.Sum(t => t.ItemQty);
             int Bcost = sidB.Select(t=>t.ItemCost).FirstOrDefault();
            if (totalQty % 2 == 0)
            {
                totalcost = (totalQty / 2) * 45;
            }
            else
            {
                totalcost = (totalQty / 2) * 45 + Bcost;
            }

            return totalcost;
            
        }

        public int calculateCandD(List<cartDetails> sidCandD)
        {
            int totalcost = 0;
            int totalCQty = sidCandD.Where(t=>t.ItemName=="C").Sum(t => t.ItemQty);
            int Ccost = sidCandD.Where(t => t.ItemName == "C").Select(t => t.ItemCost).FirstOrDefault();
            int totalDQty = sidCandD.Where(t => t.ItemName == "D").Sum(t => t.ItemQty);
            int Dcost = sidCandD.Where(t => t.ItemName == "D").Select(t => t.ItemCost).FirstOrDefault();
            if (totalCQty >= 1 && totalDQty >= 1)
            {
                if (totalCQty == totalDQty)
                {
                    totalcost = 30 * totalCQty;
                }
                
            }
            else
            {
                totalcost = (totalCQty * Ccost) + (totalDQty * Dcost);
            }
           

            return totalcost;
        }
    }



    public class cartDetails 
    {
        public string ItemName { get; set; }
        public int ItemCost { get; set; }
        public int ItemQty { get; set; }
    }
}
