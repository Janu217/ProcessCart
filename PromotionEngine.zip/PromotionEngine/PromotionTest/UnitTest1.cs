﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PromotionProcess;
using System.Collections.Generic;
using PromotionProcess.Properties;
using System.Globalization; 
using System.Resources;
using System.Reflection;

namespace PromotionTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ScenarioA()
        {
            activePromotionsCalculations act = new activePromotionsCalculations();            
            ResourceManager rm = new ResourceManager("PromotionProcess.Resources",  Assembly.GetExecutingAssembly());
            List<cartDetails> cartDetails = new List<PromotionProcess.cartDetails>()
            {
                 new cartDetails() {ItemName = "A", ItemCost = 50, ItemQty =1},
                 new cartDetails() {ItemName = "B", ItemCost = 30, ItemQty =1},
                 new cartDetails() {ItemName = "C", ItemCost = 20, ItemQty =1}
            };
            int totalCost = act.totalCost(cartDetails);
            Assert.AreEqual(100, totalCost);
           
        }

        [TestMethod]
        public void ScenarioB()
        {
            activePromotionsCalculations act = new activePromotionsCalculations();
            ResourceManager rm = new ResourceManager("PromotionProcess.Resources", Assembly.GetExecutingAssembly());
            List<cartDetails> cartDetails = new List<PromotionProcess.cartDetails>()
            {
                 new cartDetails() {ItemName = "A", ItemCost = 50, ItemQty =5},
                 new cartDetails() {ItemName = "B", ItemCost = 30, ItemQty =5},
                 new cartDetails() {ItemName = "C", ItemCost = 20, ItemQty =1}
            };
            int totalCost = act.totalCost(cartDetails);
            Assert.AreEqual(370, totalCost);

        }

        [TestMethod]
        public void ScenarioC()
        {
            activePromotionsCalculations act = new activePromotionsCalculations();
            ResourceManager rm = new ResourceManager("PromotionProcess.Resources", Assembly.GetExecutingAssembly());
            List<cartDetails> cartDetails = new List<PromotionProcess.cartDetails>()
            {
                 new cartDetails() {ItemName = "A", ItemCost = 50, ItemQty =3},
                 new cartDetails() {ItemName = "B", ItemCost = 30, ItemQty =5},
                 new cartDetails() {ItemName = "C", ItemCost = 20, ItemQty =1},
                 new cartDetails() {ItemName = "D", ItemCost = 15, ItemQty =1}
            };
            int totalCost = act.totalCost(cartDetails);
            Assert.AreEqual(280, totalCost);

        }
    }
}
